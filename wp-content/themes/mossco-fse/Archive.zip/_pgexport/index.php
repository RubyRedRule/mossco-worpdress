<?php get_header(); ?>

<main style="position: relative;">
    <section class="border-b-4 border-primary-NORMAL border-solid hero-poster hero-shadow relative text-white" id="hero-poster">
        <div class="bg-opacity-60 bg-primary_bg-NORMAL">
            <header class="container mx-auto"> 
                <nav class="flex flex-wrap items-center justify-between px-4 py-5"> 
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/logo-white-teal.svg" class="mr-auto sm:hidden">
                    <button class="hamburger-menu hover:text-white px-3 py-2 rounded text-current lg:hidden" data-name="nav-toggler" data-pg-ia='{"l":[{"name":"NabMenuToggler","trg":"click","a":{"l":[{"t":"^nav|[data-name=nav-menu]","l":[{"t":"set","p":0,"d":0,"l":{"class.remove":"hidden"}}]},{"t":"#gt# span:nth-of-type(1)","l":[{"t":"tween","p":0,"d":0.2,"l":{"rotationZ":45,"yPercent":300}}]},{"t":"#gt# span:nth-of-type(2)","l":[{"t":"tween","p":0,"d":0.2,"l":{"autoAlpha":0}}]},{"t":"#gt# span:nth-of-type(3)","l":[{"t":"tween","p":0,"d":0.2,"l":{"rotationZ":-45,"yPercent":-300}}]}]},"pdef":"true","trev":"true"}]}' data-pg-ia-apply="$nav [data-name=nav-toggler]">
                        <span class="bg-primary-NORMAL block h-1 hover:bg-primary-LIGHT my-2 rounded w-12"></span>
                        <span class="block rounded ml-auto w-8 h-1 my-2.5 bg-white"></span>
                        <span class="bg-primary-NORMAL block h-1 hover: my-2.5 rounded w-12"></span>
                    </button>
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo/logo-white-teal.svg" class="mossco-logo">
                    <a href="#" class="bg-primary-NORMAL font-light hover:bg-primary-700 inline-block nav-btn-tablet-mobile px-5 py-2 rounded text-current text-primary-500 uppercase"><?php _e( 'Book a Table', 'mossco_tw' ); ?></a>
                    <div class="lg:flex lg:space-x-4 lg:space-y-0 lg:w-auto space-y-2 w-full hidden lg:items-center" data-name="nav-menu"> 
                        <div class="flex flex-col text-gray-50 lg:flex-row lg:text-sm"> <a href="#" class="font-light px-0 py-2 uppercase md:hover:text-primary-LIGHT lg:px-4"><?php _e( 'Our Story', 'mossco_tw' ); ?></a> <a href="#" class="font-light hover:text-blue-600 px-0 py-2 uppercase md:hover:text-primary-LIGHT lg:px-4"><?php _e( 'Menus', 'mossco_tw' ); ?></a> <a href="#" class="font-light hover:text-blue-600 px-0 py-2 uppercase md:hover:text-primary-LIGHT lg:px-4"><?php _e( 'Bar &#38; Restaurant', 'mossco_tw' ); ?></a> <a href="#" class="font-light hover:text-blue-600 px-0 py-2 uppercase md:hover:text-primary-LIGHT lg:px-4"><?php _e( 'Location', 'mossco_tw' ); ?></a> <a href="#" class="font-light hover:text-blue-600 px-0 py-2 uppercase md:hover:text-primary-LIGHT lg:px-4"><?php _e( 'Gallery', 'mossco_tw' ); ?></a> <a href="#" class="font-light hover:text-blue-600 px-0 py-2 uppercase md:hover:text-primary-LIGHT lg:px-4"><?php _e( 'Newsletter', 'mossco_tw' ); ?></a>
                        </div>                                 <a href="#" class="bg-primary-NORMAL font-light hover:bg-primary-700 inline-block px-5 py-2 rounded text-current text-primary-500 uppercase"><?php _e( 'Book a Table', 'mossco_tw' ); ?></a> 
                    </div>                             
                </nav>                         
            </header>
        </div>
        <div class="flex mx-4">
            <div class="text-center w-full">
                <h1 class="bg-opacity-0 font-sans lowercase text-3xl sm:text-5xl md:text-5xl lg:text-6xl 2xl:text-7xl"><?php _e( 'bar | kitchen | terrace', 'mossco_tw' ); ?></h1>
                <h2 class="font-serif mt-4 pb-4 2xl:font-serif 2xl:leading-normal 2xl:text-3xl 2xl:text-primary-NORMAL"><?php _e( 'FOOD &amp; DRINK WITH STYLE', 'mossco_tw' ); ?></h2>
                <button class="bg-opacity-50 bg-primary_bg-NORMAL border-2 border-primary-NORMAL border-solid mt-5 px-8 py-2 rounded uppercase">
                    <?php _e( 'View Menu', 'mossco_tw' ); ?>
                </button>
            </div>
        </div>
    </section>             
</main>                 

<?php get_footer(); ?>